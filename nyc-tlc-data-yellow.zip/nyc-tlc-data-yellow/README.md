# nyc-tlc-data
Backup for NYC TLC data for the DE Zoomcamp course
